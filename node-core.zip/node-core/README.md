## distribute project to servers ##

>gulp upload --env dev   // upload project to dev.engyne.net

>gulp upload --env local // upload project to 192.168.1.188


## restart node programs ##

1. login into server

>ssh root@dev.engyne.net
>forever restartall
